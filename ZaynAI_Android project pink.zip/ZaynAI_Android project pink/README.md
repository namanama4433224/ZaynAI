# Zayn AI – proyek Android awal

Proyek ini adalah **source code Android Studio**, bukan APK siap instal.

## Fitur yang sudah disiapkan
- Izin robot mengambang (Android `SYSTEM_ALERT_WINDOW`).
- Tombol robot mengambang "Z".
- Permintaan izin screen capture Android (MediaProjection).
- OCR teks layar menggunakan Google ML Kit Text Recognition.
- Hasil teks yang terbaca ditampilkan di aplikasi.

## Yang belum tersedia
- Mesin AI yang menyelesaikan soal secara otomatis. OCR hanya mengubah gambar menjadi teks.
- Endpoint backend AI yang aman. Jangan menanam API key di APK atau membagikannya di chat.
- Build dan uji di berbagai perangkat/versi Android.

## Cara membuka
1. Pasang Android Studio versi terbaru.
2. Pilih **Open** dan buka folder `ZaynAI_Android`.
3. Tunggu Gradle Sync selesai (perlu internet untuk mengunduh dependensi).
4. Jalankan di perangkat Android untuk pengujian.
5. Di aplikasi, izinkan tampilan di atas aplikasi lain.
6. Tekan tombol izin membaca layar dan setujui dialog Android.
7. Buka halaman soal lalu ketuk bubble Z untuk memindai.

## Catatan penting
- Android dapat membatasi screen capture pada layar sensitif atau aplikasi yang memblokir tangkapan layar.
- Persetujuan screen capture harus diberikan oleh pengguna.
- Aplikasi lain mungkin menampilkan layar hitam saat direkam.
- Target SDK dan persyaratan foreground service dapat berubah mengikuti versi Android.
- Ini starter project; perlu pengujian, penyempurnaan UI, dan backend AI sebelum dipakai sehari-hari.
