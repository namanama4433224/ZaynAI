package id.zayn.ai

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class ResultActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getStringExtra("recognizedText").orEmpty()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        val title = TextView(this).apply {
            this.text = "Zayn AI • Hasil pembacaan"
            textSize = 21f; setTextColor(0xFFFFFFFF.toInt())
        }
        val body = TextView(this).apply {
            this.text = if (text.isBlank()) "Tidak ada teks yang terbaca. Pastikan soal terlihat jelas." else text
            textSize = 15f; setTextColor(0xFFE2EEFF.toInt()); setPadding(0, 18, 0, 18)
        }
        val info = TextView(this).apply {
            text = "Teks hasil OCR ditampilkan di atas. Untuk menghasilkan jawaban AI otomatis, proyek ini perlu dihubungkan ke backend AI yang aman; jangan memasukkan API key rahasia ke aplikasi."
            textSize = 12f; setTextColor(0xFF9AABC2.toInt())
        }
        val close = Button(this).apply { text = "Tutup"; setOnClickListener { finish() } }
        layout.addView(title); layout.addView(body); layout.addView(info); layout.addView(close)
        setContentView(layout)
    }
}
