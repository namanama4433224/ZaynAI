package id.zayn.ai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 501
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        fun label(text: String, size: Float, color: Int) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            setPadding(0, 12, 0, 12)
        }
        layout.addView(label("🤖  ZAYN AI", 28f, 0xFFFFFFFF.toInt()))
        layout.addView(label("Asisten belajar mengambang", 16f, 0xFF9CC7E8.toInt()))
        status = label("Aktifkan izin yang diperlukan, lalu mulai membaca layar.", 14f, 0xFFFFFFFF.toInt())
        layout.addView(status)

        val overlay = Button(this).apply {
            text = "1. Aktifkan robot mengambang"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                    status.text = "Robot mengambang aktif. Buka aplikasi soal, lalu ketuk robot."
                }
            }
        }
        layout.addView(overlay)

        val start = Button(this).apply {
            text = "2. Izinkan membaca layar"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        }
        layout.addView(start)
        layout.addView(label(
            "Privasi: Android akan menampilkan konfirmasi sebelum layar dibagikan. " +
            "Zayn hanya mengambil layar setelah kamu menyetujui. Tutup sesi dari notifikasi untuk berhenti.",
            12f, 0xFF9AABC2.toInt()
        ))
        setContentView(layout)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            startForegroundService(i)
            status.text = "Izin layar diberikan. Ketuk robot Zayn untuk memindai soal."
        } else if (requestCode == captureRequest) {
            status.text = "Izin membaca layar belum diberikan."
        }
    }
}
