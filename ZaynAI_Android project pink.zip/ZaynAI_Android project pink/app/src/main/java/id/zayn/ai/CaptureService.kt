package id.zayn.ai

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {
    companion object { const val ACTION_SCAN = "id.zayn.ai.SCAN" }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var receiver: BroadcastReceiver? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        if (projection == null && intent != null) {
            val code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra("projectionData", Intent::class.java)
            else @Suppress("DEPRECATION") (intent.getParcelableExtra("projectionData") as? Intent)
            if (data != null) {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = mgr.getMediaProjection(code, data)
                startProjection()
            }
        }
        if (receiver == null) {
            receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) { scanScreen() }
            }
            registerReceiver(receiver, IntentFilter(ACTION_SCAN))
        }
        return START_STICKY
    }

    private fun createNotification() {
        val channel = "zayn_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "Zayn screen reading", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, channel)
            .setContentTitle("Zayn AI aktif")
            .setContentText("Sesi pembacaan layar aktif. Hentikan dengan menutup sesi ini.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(7, n)
    }

    private fun startProjection() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "ZaynScreen", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null
        )
    }

    private fun scanScreen() {
        val image = reader?.acquireLatestImage()
        if (image == null) {
            Toast.makeText(this, "Belum ada gambar layar. Coba ketuk robot lagi.", Toast.LENGTH_SHORT).show()
            return
        }
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        image.close()
        val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        bitmap.recycle()
        val input = InputImage.fromBitmap(cropped, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val text = result.text
                val i = Intent(this, ResultActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra("recognizedText", text)
                }
                startActivity(i)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal membaca teks layar.", Toast.LENGTH_LONG).show()
            }
            .addOnCompleteListener { cropped.recycle(); recognizer.close() }
    }

    override fun onDestroy() {
        try { receiver?.let { unregisterReceiver(it) } } catch (_: Exception) {}
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
