
package id.zayn.ai

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private var wm: WindowManager? = null
    private var robot: LinearLayout? = null
    private var menu: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams

    private fun dp(n: Int): Int =
        (n * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun text(
        value: String,
        size: Float,
        color: Int
    ) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(5), dp(8), dp(5))
    }

    override fun onCreate() {
        super.onCreate()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        robot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = shape(Color.rgb(255, 220, 238), 20)
            setPadding(dp(5), dp(4), dp(5), dp(4))

            addView(text("🎓", 19f, Color.BLACK))
            addView(text("◕‿◕", 17f, Color.rgb(230, 65, 135)))
            addView(text("Zayn AI", 10f, Color.rgb(170, 35, 100)))
        }

        params = WindowManager.LayoutParams(
            dp(76),
            dp(94),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(180)
        }

        var startX = 0f
        var startY = 0f
        var oldX = 0
        var oldY = 0
        var moved = false

        robot?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startY = event.rawY
                    oldX = params.x
                    oldY = params.y
                    moved = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - startX).toInt()
                    val dy = (event.rawY - startY).toInt()

                    if (kotlin.math.abs(dx) > dp(5) ||
                        kotlin.math.abs(dy) > dp(5)) {
                        moved = true
                    }

                    if (moved) {
                        params.x = oldX + dx
                        params.y = oldY + dy
                        robot?.let { wm?.updateViewLayout(it, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!moved) showMenu()
                    true
                }

                else -> true
            }
        }

        wm?.addView(robot, params)
    }

    private fun showMenu() {
        hideMenu()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(Color.WHITE, 16)
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }

        fun addOption(label: String, action: () -> Unit) {
            val button = TextView(this).apply {
                text = label
                textSize = 12f
                setTextColor(Color.rgb(150, 35, 90))
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = shape(Color.rgb(255, 232, 244), 10)
                setOnClickListener {
                    hideMenu()
                    action()
                }
            }

            panel.addView(button)
        }

        addOption("📖  Baca soal latihan") {
            sendBroadcast(Intent(CaptureService.ACTION_SCAN))
            Toast.makeText(this, "Memindai layar…", Toast.LENGTH_SHORT).show()
        }

        addOption("💡  Jelaskan soal") {
            sendBroadcast(Intent(CaptureService.ACTION_SCAN))
            Toast.makeText(this, "Membaca soal untuk dijelaskan.", Toast.LENGTH_SHORT).show()
        }

        addOption("✖  Tutup menu") {
            hideMenu()
        }

        menu = panel

        val menuParams = WindowManager.LayoutParams(
            dp(175),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = params.x
            y = params.y + dp(98)
        }

        try {
            wm?.addView(menu, menuParams)
        } catch (_: Exception) {
            menu = null
        }
    }

    private fun hideMenu() {
        try {
            menu?.let { wm?.removeView(it) }
        } catch (_: Exception) {
        }
        menu = null
    }

    override fun onDestroy() {
        hideMenu()
        try {
            robot?.let { wm?.removeView(it) }
        } catch (_: Exception) {
        }
        robot = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
